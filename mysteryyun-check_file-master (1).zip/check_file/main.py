
#! /usr/bin env python3
# -- coding:utf-8 --


from application import Application


def main():
    app = Application()
    app.run()


if __name__ == '__main__':
    print(" -- Ⓢ ⓣ ⓐ ⓡ ⓣ (っ• ̀ω•́ )っ | check_file --\n")
    main()
