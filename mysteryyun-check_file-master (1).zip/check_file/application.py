
#! /usr/bin env python3
# -- coding:utf-8 --


from queue import Queue
from worker_check import WorkerCheck
from worker_out import WorkerOut
from worker_copy import WorkerCopy


class Application:
    def __init__(self):
        checkFile = "F:/dep/code/python/jdm/check_file/data/test/target/change.txt"
        checkPrefix = "F:/dep/code/python/jdm/check_file/data/test/Python_master"
        outPrefix = "F:/dep/code/python/jdm/check_file/result"
        copyPrefix = "F:/dep/code/python/jdm/check_file/result"

        self.outQueue = Queue()
        self.copyQueue = Queue()
        self.workerCheck = WorkerCheck(outQueue=self.outQueue, copyQueue=self.copyQueue, file=checkFile, prefix=checkPrefix, debug=True)
        self.workerOut = WorkerOut(queue=self.outQueue, prefix=outPrefix, debug=True)
        self.workerCopy = WorkerCopy(queue=self.copyQueue, copyPrefix=copyPrefix, checkPrefix=checkPrefix, debug=True)

    def run(self):
        print("-- Application::run start")
        self.workerOut.start()
        self.workerCopy.start()
        self.workerCheck.start()

        self.workerCheck.join()
        self.workerOut.join()
        self.workerCopy.join()
        print("-- Application::run stop")
