
#! /usr/bin env python3
# -- coding:utf-8 --


import threading
import os


class WorkerCheck (threading.Thread):
    def __init__(self, outQueue, copyQueue, file, prefix, debug=False):
        threading.Thread.__init__(self)
        self.outQueue = outQueue
        self.copyQueue = copyQueue
        self.file = file 
        self.prefix = prefix
        self.debug = debug

    def run(self):
        print("-- WorkerCheck::run start")

        with open(self.file) as f:
            for line in f:
                line = line.strip('\r\n \t')
                if self.debug:
                    print("-- WorkerCheck line |", line)

                if os.path.exists(os.path.join(self.prefix, line)):
                    self.outQueue.put([1, line])
                    self.copyQueue.put([1, line])
                else:
                    self.outQueue.put([2, line])
                    self.copyQueue.put([2, line])

            f.close()

        self.outQueue.put([99, ""])
        self.copyQueue.put([99, ""])
        print("-- WorkerCheck::run stop")
