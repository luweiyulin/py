
#! /usr/bin env python3
# -- coding:utf-8 --


import threading
import os


class WorkerOut (threading.Thread):
    def __init__(self, queue, prefix, mod="", add="", debug=False):
        threading.Thread.__init__(self)
        self.queue = queue
        self.prefix = prefix
        self.mod = mod if mod != "" else "mod.txt"
        self.add = add if add != "" else "add.txt"
        self.debug = debug

        dirs = os.path.split(prefix)[0]
        if not os.path.isdir(dirs):
            os.makedirs(dirs)

    def run(self):
        print("-- WorkerOut::run start")

        mod = open(os.path.join(self.prefix, self.mod), mode="w")
        add = open(os.path.join(self.prefix, self.add), mode="w")

        line = self.queue.get()
        while (line[0] != 99):
            if self.debug:
                print("-- WorkerOut line |", line)
            
            if line[0] == 1 :
                mod.write(line[1] + "\n")
            elif line[0] == 2:
                add.write(line[1] + "\n")
            line = self.queue.get()

        mod.close()
        add.close()

        print("-- WorkerOut::run stop")
