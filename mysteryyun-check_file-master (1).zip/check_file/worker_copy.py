
#! /usr/bin env python3
# -- coding:utf-8 --


import threading
import os
import shutil


class WorkerCopy (threading.Thread):
    def __init__(self, queue, copyPrefix, checkPrefix, debug=False):
        threading.Thread.__init__(self)
        self.queue = queue
        self.copyPrefix = copyPrefix
        self.checkPrefix = checkPrefix 
        self.debug = debug


    def run(self):
        print("-- WorkerCopy::run start")

        line = self.queue.get()
        while (line[0] != 99):
            if self.debug:
                print("-- WorkerCopy line |", line)
            
            if line[0] == 1 :
                self.copyFile(os.path.join(self.checkPrefix, line[1]), os.path.join(self.copyPrefix, line[1]))
            elif line[0] == 2:
                self.createFile(os.path.join(self.copyPrefix, line[1]))
            line = self.queue.get()

        print("-- WorkerCopy::run stop")

    
    def formatPath(self, path: str):
        return path.replace(r'\/'.replace(os.sep, ''), os.sep)

    def checkDir(self, path):
        dirs = os.path.split(path)[0]
        if not os.path.isdir(dirs):
            os.makedirs(dirs)

    def copyFile(self, src, dst):
        self.checkDir(dst)
        shutil.copy(src, dst)

    def createFile(self, path):
        self.checkDir(path)
        with open(path, mode="w") as f:
            f.close()
